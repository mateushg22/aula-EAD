extends Area2D



func _on_area_entered(area: Area2D) -> void:
	
	
	if area.is_in_group("player"):
		$AnimatedSprite2D.play("collected")
		$CollisionShape2D.queue_free()
		
		
		await get_tree().create_timer(1.0).timeout
		
		queue_free()
	
	
	pass 
