extends RigidBody2D

var speed = 500
var dir = [-1, 1]

# Variaveis compartilhadas entre as bolas
static var score_p1 = 0
static var score_p2 = 0
static var rodada = 1

func _ready() -> void:
	add_to_group("bolas")
	body_entered.connect(_on_body_entered)
	atualizar_placar()
	
	# So reseta se for a primeira bola da cena
	if get_tree().get_nodes_in_group("bolas").size() == 1:
		reset()

func _physics_process(delta: float) -> void:
	score()

func reset():
	global_position = get_viewport_rect().size / 2
	freeze = true
	linear_velocity = Vector2.ZERO
	
	await get_tree().create_timer(1.5).timeout
	
	freeze = false
	apply_central_impulse(Vector2(dir.pick_random() * speed, dir.pick_random() * speed))

func score():
	# Gol do Player 1
	if global_position.x >= get_viewport_rect().size.x:
		score_p1 += 1
		mudar_rodada()
		
	# Gol do Player 2
	elif global_position.x <= 0:
		score_p2 += 1
		mudar_rodada()

func mudar_rodada():
	rodada += 1
	if rodada > 3:
		rodada = 1
		
	atualizar_placar()
	limpar_ou_resetar()

func atualizar_placar():
	if has_node("../score"):
		$"../score".text = str(score_p1) + ":" + str(score_p2) + " (R" + str(rodada) + ")"

func _on_body_entered(body: Node) -> void:
	if body.name == "Player" or body.name == "Player2":
		
		# Rodada 1: Normal (bate e volta)
		if rodada == 1:
			pass
			
		# Rodada 2: Duplica (limite de 2 bolas)
		if rodada == 2:
			if get_tree().get_nodes_in_group("bolas").size() < 2:
				var nova = self.duplicate()
				get_parent().add_child(nova)
				
				# Afasta um pouco para nao travar no player
				var lado = -1 if body.name == "Player2" else 1
				nova.global_position = global_position + Vector2(lado * 30, 0)
				
		# Rodada 3: Some (chama no proximo quadro da fisica para nao travar)
		if rodada == 3:
			call_deferred("limpar_ou_resetar")

func limpar_ou_resetar():
	if get_tree().get_nodes_in_group("bolas").size() <= 1:
		reset()
	else:
		queue_free()
