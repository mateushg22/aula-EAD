extends CharacterBody2D

var speed = 300
var jump_velocity= -300.0

var dir 

var gravity = 980

var jumps = 1

@onready var anim = $AnimatedSprite2D
func _ready() -> void:
	
	pass
	
func _physics_process(delta: float) -> void:
	
	move(delta)
	animations()
	pass
	
func move(delta):
	
	dir = Input.get_axis("left","right")
	
	
	velocity.x= dir * speed
	
	if not is_on_floor():
		velocity.y += gravity * delta
	
	if Input.is_action_just_pressed("jump") and jumps > 0:
		velocity.y = jump_velocity
		jumps -= 1
		
		if is_on_floor():
			jumps = 5
		
	move_and_slide()
	
	pass
	
func animations():
		
		if velocity.x != 0 and is_on_floor():
			anim.play("run")
		elif velocity.x== 0 and is_on_floor():
			anim.play("idle")
			
			
		if not is_on_floor() and jumps >= 1:
			anim.play("jump")
			
		pass
		
		
