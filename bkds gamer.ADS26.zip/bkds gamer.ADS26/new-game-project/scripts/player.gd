extends CharacterBody2D

var speed = 300
var jump_velocity= -300.0

var dir 

var gravity = 980

var jumps = 1

@onready var anim = $AnimatedSprite2D

var is_alive = true

func _ready() -> void:
	add_to_group("player")
	pass
	
func _physics_process(delta: float) -> void:
	
	move(delta)
	
	if is_alive:
		animations()
	
	pass
	
func move(delta):
	
	if is_alive:
		dir = Input.get_axis("left","right")
	
	
	velocity.x= dir * speed
	
	if not is_on_floor():
		velocity.y += gravity * delta
	
	if Input.is_action_just_pressed("jump") and jumps > 0 and is_alive:
		velocity.y = jump_velocity
		jumps -= 1
		
		if is_on_floor():
			jumps = 5
		
	move_and_slide()
	
	pass
	
func animations():
	
	if velocity.x != 0 and is_on_floor():
		anim.play("run")
	elif velocity.x== 0 and is_on_floor():
		anim.play("idle")
		
		
	if not is_on_floor() and jumps >= 1:
		anim.play("jump")
		
		
	if dir > 0:
		anim.flip_h = false
	elif dir < 0:
		anim.flip_h = true
		
	pass
		
	
func die():
	
		is_alive = false
		anim.play("die")
		
		$Area2D.queue_free()
		$CollisionShape2D.queue_free()
		velocity.y = -300.00
		
		$Camera2D.zoom = Vector2(1.5 , 1.5)
		Engine.time_scale = 0.3
		
		await get_tree().create_timer(1.0).timeout
		
		Engine.time_scale = 1
		
		Global.score = 0
		get_tree().reload_current_scene()
		
		pass

func next_level():
	var current_scene = get_tree().current_scene.scene_file_path
	
	if "level_1" in current_scene:
		get_tree().change_scene_to_file("res://scenes/level_2.tscn")
	elif "level_2" in current_scene:
		get_tree().change_scene_to_file("res://scenes/level_3.tscn")
	elif "level_3" in current_scene:
		get_tree().change_scene_to_file("res://scenes/level_1.tscn")
