extends Area2D

# Cria uma caixa no Inspetor para escolheres a cena do próximo nível
@export_file("*.tscn") var next_level: String

# Evita que o sinal seja ativado várias vezes enquanto o jogador está a tocar na bandeira
var is_transitioning: bool = false

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player") and not is_transitioning:
		is_transitioning = true
		
		# 1. Guarda a pontuação atual como a base/checkpoint da próxima fase
		Global.start_new_level()
		
		# 2. ESPERA 1 SEGUNDO antes de mudar a cena (podes ajustar este tempo)
		await get_tree().create_timer(1.0).timeout
		
		# 3. Muda para o próximo nível configurado
		if next_level != "":
			get_tree().change_scene_to_file(next_level)
		else:
			get_tree().change_scene_to_file("res://scenes/level_2.tscn")
