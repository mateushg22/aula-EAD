extends Label

func _process(_delta: float) -> void:
	text = "P1: " + str(Global.score)
