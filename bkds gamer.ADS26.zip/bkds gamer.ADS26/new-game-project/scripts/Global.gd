extends Node

var score: int = 0      # Pontuação do Player 1
var score_p2: int = 0   # Pontuação do Player 2

var level_start_score: int = 0
var level_start_p2: int = 0

var is_p1_alive: bool = true
var is_p2_alive: bool = true

func start_new_level() -> void:
	level_start_score = score
	level_start_p2 = score_p2
	is_p1_alive = true
	is_p2_alive = true

func reset_to_level_start_score() -> void:
	score = level_start_score
	score_p2 = level_start_p2
	is_p1_alive = true
	is_p2_alive = true

func player_died(player_name: String) -> void:
	if player_name == "Player" or player_name == "Player1" or player_name == "player1":
		is_p1_alive = false
	elif player_name == "Player2" or player_name == "player2":
		is_p2_alive = false
	
	if not is_p1_alive and not is_p2_alive:
		Engine.time_scale = 1.0
		reset_to_level_start_score()
		get_tree().reload_current_scene()

func add_score(player_name: String, amount: int = 1) -> void:
	if player_name == "Player" or player_name == "Player1" or player_name == "player1":
		score += amount
	elif player_name == "Player2" or player_name == "player2":
		score_p2 += amount
