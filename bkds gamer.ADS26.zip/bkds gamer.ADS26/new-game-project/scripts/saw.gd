extends Area2D

@export_category("Movement Settings")

@export_enum("Up", "Down", "Left", "Right")
var move_dir: int

@export var speed: float = 100.0

@export_range(50.0, 500.0, 5.0, "Distância máxima da serra")
var distance: float = 50.0

var dir: Vector2
@onready var start_position = global_position

func _ready() -> void:
	set_dir()
	# Conecta a colisão automaticamente ao iniciar
	body_entered.connect(_on_body_entered)
	area_entered.connect(_on_area_entered)

func _physics_process(delta: float) -> void:
	move(delta)

func set_dir() -> void:
	dir = Vector2.ZERO
	match move_dir:
		0: dir = Vector2.UP
		1: dir = Vector2.DOWN
		2: dir = Vector2.LEFT
		3: dir = Vector2.RIGHT

func move(delta: float) -> void:
	global_position += dir * speed * delta
	if global_position.distance_to(start_position) >= distance:
		dir = -dir
		start_position = global_position

# Lógica de colisão com o jogador
func _on_body_entered(body: Node2D) -> void:
	_handle_player_death(body)

func _on_area_entered(area: Area2D) -> void:
	# Se a colisão detetar a Area2D do jogador (Hurtbox/Hitbox)
	if area.is_in_group("player"):
		_handle_player_death(area.get_parent())

func _handle_player_death(player: Node) -> void:
	if player and player.is_in_group("player"):
		# 1. Regista no Global qual o jogador que morreu ("Player", "Player1" ou "Player2")
		Global.player_died(player.name)
		
		# 2. Esconde e desativa apenas o jogador atingido
		player.hide()
		player.set_process(false)
		player.set_physics_process(false)
		
		# 3. Desativa as colisões para não ser atingido novamente enquanto inativo
		for child in player.get_children():
			if child is CollisionShape2D or child is CollisionPolygon2D:
				child.set_deferred("disabled", true)
