extends Area2D

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
	# Verifica se quem colidiu pertence ao grupo de jogadores
	if body.is_in_group("player"):
		# Compara o nome exato do nó que colidiu
		if body.name == "Player" or body.name == "Player1":
			Global.add_score("player1", 1)
		elif body.name == "Player2":
			Global.add_score("player2", 1)
		else:
			# Caso o nó do Player 2 tenha outro nome, tenta identificar pelo script ou grupo
			Global.add_score("player2", 1)
			
		queue_free() # Remove a fruta da cena
