extends CharacterBody2D

# 1. Variáveis configuráveis no Inspetor do Godot:
@export var key_up: Key
@export var key_down: Key
@export var key_right: Key
@export var key_left: Key

var speed = 300.0
var jump_velocity = -350.0
var dir = 0.0
var gravity = 980.0
var jumps = 1

@onready var anim = $AnimatedSprite2D
var is_alive = true

func _ready() -> void:
	add_to_group("player")
	
	# Garante que a câmera segue este jogador se não houver outra ativa
	if not has_node("Camera2D"):
		var cam = Camera2D.new()
		cam.make_current()
		add_child(cam)

func _physics_process(delta: float) -> void:
	if is_alive:
		move(delta)
		animations()

func move(delta: float) -> void:
	dir = 0.0
	
	# Movimento Horizontal pelas setas configuradas
	if key_right != KEY_NONE and Input.is_key_pressed(key_right):
		dir += 1.0
	if key_left != KEY_NONE and Input.is_key_pressed(key_left):
		dir -= 1.0
	
	velocity.x = dir * speed

	# Aplicação da gravidade
	if not is_on_floor():
		velocity.y += gravity * delta
	else:
		jumps = 1 # Recarrega o pulo ao tocar no chão

	# Pulo com a seta para cima (key_up)
	if key_up != KEY_NONE and Input.is_key_pressed(key_up) and jumps > 0:
		velocity.y = jump_velocity
		jumps -= 1

	move_and_slide()

func animations() -> void:
	if velocity.x != 0 and is_on_floor():
		anim.play("run")
	elif velocity.x == 0 and is_on_floor():
		anim.play("idle")
		
	if not is_on_floor():
		anim.play("jump")
		
	if dir > 0:
		anim.flip_h = false
	elif dir < 0:
		anim.flip_h = true

func die() -> void:
	is_alive = false
	anim.play("die")
	
	if has_node("Area2D"):
		$Area2D.queue_free()
	if has_node("CollisionShape2D"):
		$CollisionShape2D.queue_free()
		
	velocity.y = -300.0
	Engine.time_scale = 0.3
	
	await get_tree().create_timer(1.0).timeout
	
	Engine.time_scale = 1.0
	Global.score = 0
	get_tree().reload_current_scene()

func next_level() -> void:
	var current_scene = get_tree().current_scene.scene_file_path
	
	if "level_1" in current_scene:
		get_tree().change_scene_to_file("res://scenes/level_2.tscn")
	elif "level_2" in current_scene:
		get_tree().change_scene_to_file("res://scenes/level_3.tscn")
	elif "level_3" in current_scene:
		get_tree().change_scene_to_file("res://scenes/level_1.tscn")
