extends Camera2D

var player1: Node2D = null
var player2: Node2D = null

# Configurações de Zoom e Margem
@export var min_zoom: float = 0.7   # Zoom máximo de afastamento
@export var max_zoom: float =  0.6  # Zoom máximo de aproximação
@export var margin: Vector2 = Vector2(300, 200) # Margem de segurança

func _ready() -> void:
	make_current()
	find_players()

func _process(delta: float) -> void:
	if not is_instance_valid(player1) or not is_instance_valid(player2):
		find_players()
	
	# Verifica se o nó existe E se está vivo segundo o Global
	var p1_alive = is_instance_valid(player1) and Global.is_p1_alive
	var p2_alive = is_instance_valid(player2) and Global.is_p2_alive

	# 1. POSICIONAMENTO DA CÂMARA
	if p1_alive and p2_alive:
		# Ponto médio entre os dois jogadores
		var center_pos = (player1.global_position + player2.global_position) / 2.0
		global_position = global_position.lerp(center_pos, 5.0 * delta)
		
		# Ajusta zoom para focar os dois
		adjust_zoom(delta)
		
	elif p1_alive:
		# Foca apenas no Player 1 se ele estiver vivo
		global_position = global_position.lerp(player1.global_position, 5.0 * delta)
		zoom = zoom.lerp(Vector2(max_zoom, max_zoom), 3.0 * delta)
		
	elif p2_alive:
		# Foca apenas no Player 2 se ele estiver vivo
		global_position = global_position.lerp(player2.global_position, 5.0 * delta)
		zoom = zoom.lerp(Vector2(max_zoom, max_zoom), 3.0 * delta)

func adjust_zoom(delta: float) -> void:
	var rect = Rect2(player1.global_position, Vector2.ZERO)
	rect = rect.expand(player2.global_position)
	rect = rect.grow_individual(margin.x, margin.y, margin.x, margin.y)
	
	var screen_size = get_viewport_rect().size
	
	var z_x = screen_size.x / rect.size.x
	var z_y = screen_size.y / rect.size.y
	var target_zoom = clamp(min(z_x, z_y), min_zoom, max_zoom)
	
	zoom = zoom.lerp(Vector2(target_zoom, target_zoom), 3.0 * delta)

func find_players() -> void:
	var players = get_tree().get_nodes_in_group("player")
	if players.size() >= 1:
		player1 = players[0]
	if players.size() >= 2:
		player2 = players[1]
