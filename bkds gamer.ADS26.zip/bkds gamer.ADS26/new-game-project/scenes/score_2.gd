extends Label

func _process(_delta: float) -> void:
	text = "P2: " + str(Global.score_p2)
