extends Area2D

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player") or body is CharacterBody2D:
		Engine.time_scale = 1.0
		body.hide()
		body.process_mode = PROCESS_MODE_DISABLED
		Global.player_died(body.name)
